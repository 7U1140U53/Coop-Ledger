# Database Migration Guide

## Purpose

This project currently manages database migrations manually.

## Workflow

1. Create a new SQL file under `supabase/migrations/`.
2. Name it using the format:

   YYYYMMDD_description.sql

3. Execute the SQL using the Supabase SQL Editor.
4. Verify the migration completed successfully.
5. Commit the migration file to Git.
6. Never modify an applied migration. Create a new migration for subsequent changes.

## Example

20260726_database_hardening.sql