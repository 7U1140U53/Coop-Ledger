window.SUPABASE_CONFIG = {
    URL: "https://hylzqoaymdwmureerflp.supabase.co",
    ANON_KEY: "sb_publishable_rjSJEJ3vRFdplomuyOrpuA_ouSv-86K"
};
